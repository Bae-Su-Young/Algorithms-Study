#include <iostream>
#include <sstream>
#include <list>

using namespace std;
int dfs(int** graph,int x, int y, int size);

int area;

int dfs(int** graph, int x,int y,int size){
	
	if (x<=-1 || x>=size || y<=-1||y>=size){
		return -1;
	}
	if (graph[x][y]==1){
		graph[x][y]=0;
		area++;
		dfs(graph,x-1,y,size);
		dfs(graph,x,y-1,size);
		dfs(graph,x+1,y,size);
		dfs(graph,x,y+1,size);
		return 0;
	}
	return -1;
}
void solution(int sizeOfMatrix, int **matrix) {
  // TODO: 이곳에 코드를 작성하세요.
	list<int> results;
	int result=0;
	for(int i=0;i<sizeOfMatrix;i++){
		for(int j=0;j<sizeOfMatrix;j++){
			if (dfs(matrix,i,j,sizeOfMatrix)!=-1){
				result+=1;
				results.push_back(area);
				area=0;
			}
		}
	}
	
	cout<<result<<endl;
	
	//참고:losskatus.github.io/programming/c+stl-list/#1-관련-함수-정리
	list<int>::iterator iter=results.begin();
	results.sort();
	for(iter=results.begin();iter!=results.end();iter++){
		cout<<*iter<<" ";
	}
}

struct input_data {
  int sizeOfMatrix;
  int **matrix;
};

void process_stdin(struct input_data& inputData) {
  string line;
  istringstream iss;

  getline(cin, line);
  iss.str(line);
  iss >> inputData.sizeOfMatrix;

  inputData.matrix = new int*[inputData.sizeOfMatrix];
  for (int i = 0; i < inputData.sizeOfMatrix; i++) {
    getline(cin, line);
    iss.clear();
    iss.str(line);
    inputData.matrix[i] = new int[inputData.sizeOfMatrix];
    for (int j = 0; j < inputData.sizeOfMatrix; j++) {
      iss >> inputData.matrix[i][j];
    }
  }
}

int main() {
  struct input_data inputData;
  process_stdin(inputData);

  solution(inputData.sizeOfMatrix, inputData.matrix);
  return 0;
}